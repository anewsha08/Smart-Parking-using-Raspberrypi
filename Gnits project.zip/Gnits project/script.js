const homeButton = document.getElementById('homeButton');

// Add click event listener to the Home button
homeButton.addEventListener('click', function() {
    // Redirect to another page (replace 'destination.html' with the desired page URL)
    window.location.href = 'second.html';
});