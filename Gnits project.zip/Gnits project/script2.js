document.addEventListener('DOMContentLoaded', () => {
    const carGrid = document.getElementById('carGrid');
    const selectedCarMessage = document.getElementById('selectedCarMessage');
    const showSelectedButton = document.getElementById('showSelected');
    let selectedCars = [];

    // Event listener for clicking on a car
    carGrid.addEventListener('click', (e) => {
        if (e.target.classList.contains('car')) {
            if (!e.target.classList.contains('booked')) {
                e.target.classList.toggle('selected'); // Toggle the 'selected' class
                const carIndex = e.target.dataset.index; // Get the data-index attribute value
                if (selectedCars.includes(carIndex)) {
                    selectedCars = selectedCars.filter(index => index !== carIndex); // Remove from selectedCars array
                } else {
                    selectedCars.push(carIndex); // Add to selectedCars array
                }
                updateSelectedCarMessage(); // Update the selected car message
            }
        }
    });

    // Event listener for clicking on the 'Show Selected Cars' button
    showSelectedButton.addEventListener('click', () => {
        if (selectedCars.length > 0) {
            selectedCarMessage.textContent = `You have selected car numbers: ${selectedCars.join(', ')}`;
        } else {
            selectedCarMessage.textContent = 'No cars selected.';
        }
    });

    // Function to update the selected car message
    function updateSelectedCarMessage() {
        if (selectedCars.length > 0) {
            selectedCarMessage.textContent = `You have selected car numbers: ${selectedCars.join(', ')}`;
        } else {
            selectedCarMessage.textContent = 'No cars selected.';
        }
    }
});
